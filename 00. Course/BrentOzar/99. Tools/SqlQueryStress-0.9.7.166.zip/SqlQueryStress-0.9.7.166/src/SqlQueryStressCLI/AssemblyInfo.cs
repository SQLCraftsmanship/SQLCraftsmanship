﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyDescription("SQL Server Load Test Tool")]
[assembly: AssemblyCopyright("Copyright ©  2006, 2007 Adam Machanic")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en")]
[assembly: ComVisible(false)]
[assembly: Guid("e4c26a22-8376-4ff3-aa7f-878ebd9f34b3")]

[assembly: AssemblyVersion("0.9.14.0")]
