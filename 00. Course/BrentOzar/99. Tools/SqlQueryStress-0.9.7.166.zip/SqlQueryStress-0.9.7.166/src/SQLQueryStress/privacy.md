*Privacy policy*

This application does not collect or transmit any user’s personal information. If you would like to report any violations of this policy, please contact me at ejlskov@hotmail.com.
