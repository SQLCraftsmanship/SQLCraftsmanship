﻿#region

using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("SQLQueryStress")]
[assembly: AssemblyDescription("SQL Server Load Test Tool")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ejlskov@hotmail.com")]
[assembly: AssemblyProduct("SQLQueryStress")]
[assembly: AssemblyCopyright("Copyright ©  2006, 2007 Adam Machanic")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en")]
// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("e4c26a22-8376-4ff3-aa7f-878ebd9f34b3")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//

[assembly: AssemblyVersion("0.9.7.0")]
[assembly: AssemblyFileVersion("0.9.7.0")]